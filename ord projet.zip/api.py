from rest_framework import viewsets, views, response
from .models import Job, Machine, Alert, Planning
from .serializers import JobSerializer, MachineSerializer, AlertSerializer
from .scheduler import Scheduler
from .gantt import generate_gantt_chart

class JobViewSet(viewsets.ModelViewSet):
    queryset = Job.objects.all()
    serializer_class = JobSerializer

class MachineViewSet(viewsets.ModelViewSet):
    queryset = Machine.objects.all()
    serializer_class = MachineSerializer

class AlertViewSet(viewsets.ModelViewSet):
    queryset = Alert.objects.all()
    serializer_class = AlertSerializer

class UnreadAlertsCount(views.APIView):
    def get(self, request):
        return response.Response({'count': Alert.objects.filter(lu=False).count()})

class ScheduleRunView(views.APIView):
    def post(self, request):
        algo = request.data.get('algo', 'SPT')
        s = Scheduler(nom_planning="API Run")
        p = s.run_single(algo=algo, user=request.user if request.user.is_authenticated else None)
        return response.Response({'status': 'ok', 'planning_id': p.id, 'makespan': p.makespan})

class GanttDataView(views.APIView):
    def get(self, request, pk):
        html = generate_gantt_chart(pk)
        return response.Response({'html': html})
